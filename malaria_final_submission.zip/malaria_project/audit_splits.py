"""Measure source and patient overlap in the original and revised splits."""

import json
from pathlib import Path

from sklearn.model_selection import train_test_split

from train_patient_split import ROOT, SEED, image_index, split_by_patient


def source_id(path):
    return Path(path).stem.split("_cell_", 1)[0]


def main():
    frame = image_index()
    original_train, held = train_test_split(
        frame, test_size=0.30, random_state=SEED, stratify=frame.label
    )
    _, original_test = train_test_split(
        held, test_size=0.50, random_state=SEED, stratify=held.label
    )
    original_train_sources = {source_id(p) for p in original_train.path}
    original_train_patients = set(original_train.patient)
    train, validation, test = split_by_patient(frame)
    result = {
        "original_image_split": {
            "test_images": len(original_test),
            "test_images_with_source_in_training": sum(
                source_id(p) in original_train_sources for p in original_test.path
            ),
            "test_images_with_patient_in_training": sum(
                p in original_train_patients for p in original_test.patient
            ),
        },
        "revised_patient_split": {
            "train_patients": train.patient.nunique(),
            "validation_patients": validation.patient.nunique(),
            "test_patients": test.patient.nunique(),
            "patient_overlap": bool(
                set(train.patient) & set(validation.patient)
                or set(train.patient) & set(test.patient)
                or set(validation.patient) & set(test.patient)
            ),
        },
        "patient_id_source": "filename prefix before _IMG_, checked against NIH patient mapping files",
    }
    destination = ROOT / "results" / "split_audit.json"
    destination.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
