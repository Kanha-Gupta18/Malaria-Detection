# Project report: malaria cell image classification

## Aim and data

The fourth UCS321 EST statement asks for a CNN-based classifier of healthy and malaria-infected red blood cell images, with attention to class imbalance, image noise, visual variation, and interpretability. This project predicts the class of **one cell crop**, not a diagnosis for a patient or blood slide.

We used the NIH/NLM malaria cell image collection through the Kaggle mirror linked in the README. It contains 27,558 images: 13,779 Parasitized and 13,779 Uninfected. Images were decoded as RGB, resized to 160 × 160, and passed to models with their own scaling or MobileNetV2 preprocessing. Training used random horizontal flips, small rotations, and zooms. The patient-separated training run used class weights calculated from its training labels only: 0.9655 for Uninfected and 1.0371 for Parasitized.

## Why the evaluation changed

The teammate's original notebook uses a stratified 70/15/15 **image-random** split. It reported 95.45% test accuracy and 94.00% infected-cell recall for its selected custom CNN. An audit of that exact split found that all 4,134 test crops shared both a source image and a patient with the training set. Those scores are retained as archived coursework results, but they do not measure performance on new patients.

We derived patient IDs from the filename prefix before `_IMG_` and checked the pattern against the NIH patient mapping files. A new group split with seed 42 places **140 patients in training, 30 in validation, and 31 in test**, with no patient in two sets. This produced 18,539 training, 4,611 validation, and 4,408 test cell images. The dataset's original source image and patient mappings are not distributed in the submission.

## Models and selection

The original custom-CNN design was retrained from scratch on the patient split. Its selected checkpoint predicted every held-out test cell as Uninfected (0% infected-cell recall). This failure is reported in `results/patient_split_metrics.json`; that checkpoint is not used by the app.

We then trained the teammate's MobileNetV2 design from ImageNet weights: eight epochs with the base frozen, followed by three epochs fine-tuning its last 20 layers. Batch-normalization layers remained frozen. The fine-tuned checkpoint beat the frozen-head checkpoint on **validation infected-cell F1** (0.9453 versus 0.9353), so it was selected before test reporting. The selected model is `models/best_model.keras`.

| Patient-separated test metric | Selected MobileNetV2 |
|---|---:|
| Accuracy | 91.79% |
| Infected-cell precision | 97.76% |
| Infected-cell recall | 86.10% |
| Specificity | 97.89% |
| Infected-cell F1 | 91.56% |
| ROC-AUC | 0.9716 |

The confusion matrix has 2,083 true negatives, 45 false positives, **317 false negatives**, and 1,963 true positives. The test included 2,128 Uninfected and 2,280 Parasitized cells. The classification report and plots are in `results/patient_classification_report.txt` and `results/patient_test_figures.png`.

## Noise and image variation

The selected model was evaluated on the same patient-separated test images after controlled transformations. All pixels use a 0–255 scale; Gaussian noise has standard deviation 10 on that scale. Blur uses radius 1; dimming uses 80% brightness. These synthetic conditions do not cover all microscope or staining variation.

| Condition | Accuracy | Infected-cell recall | Missed infected cells |
|---|---:|---:|---:|
| Clean | 91.79% | 86.10% | 317 |
| Gaussian noise, SD 10 | 86.03% | 74.43% | 583 |
| Gaussian blur, radius 1 | 92.72% | 88.16% | 270 |
| Brightness, 80% | 91.65% | 85.66% | 327 |

The noise loss is material. A further three-epoch training experiment added Gaussian noise to half of training images. It was **rejected** because mean infected-cell F1 across clean and noisy validation images fell from 0.9034 to 0.8751. Its test results were not used for selection. Details are in `results/noise_tuning_validation.json` and `results/robustness_comparison.csv`.

## Interpretability and application

The app accepts a PNG or JPEG image, returns a predicted class and infected-class score, and overlays Grad-CAM. We tested model loading, app startup, a valid infected-cell upload, an invalid-image upload, and a real-image Grad-CAM calculation. The valid upload produced a prediction without an exception; the invalid upload produced a clear error. The Grad-CAM score matched direct model inference. `results/gradcam_cases.png` shows correct infected and uninfected predictions plus both error types. MobileNetV2's last convolutional map is only 5 × 5 before enlargement, so the overlay is coarse. It is not a parasite annotation or a clinical explanation.

## Reproducibility and limits

The scripts, working notebook, pinned dependency file, selected model, and results are included in the repository and submission ZIP. The original teammate ZIP files and raw image dataset are not needed to run the app and are excluded from the package. The model was trained and checked with Python 3.13 and TensorFlow 2.21.0 on Windows CPU. Its SHA-256 is `25d18658af1f82cfe39baca583b3ebf8005a801790fbb6339deba41b2051cd96`.

The original notebook's saved outputs were not regenerated after adding class-weight code to its working copy; its historical results are labeled separately. A severe class-imbalance scenario, external dataset validation, calibration, whole-slide analysis, and clinical validation remain outside this project. The present results should not guide diagnosis or treatment.
