"""Save Grad-CAM examples for correct and incorrect test predictions."""

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from tensorflow import keras

from evaluate_robustness import IMAGE_SIZE, ROOT, predict
from train_patient_split import image_index, split_by_patient


def main():
    _, _, test = split_by_patient(image_index())
    model = keras.models.load_model(ROOT / "models" / "best_model.keras")
    scores = predict(model, test.path.tolist(), "clean")
    predicted = scores >= 0.5
    labels = test.label.to_numpy()
    base = model.get_layer("mobilenetv2")
    intermediate = keras.Model(
        base.input, [base.get_layer("out_relu").output, base.output]
    )

    cases = [
        ("Correct infected", (labels == 1) & predicted),
        ("Correct uninfected", (labels == 0) & ~predicted),
        ("Missed infected", (labels == 1) & ~predicted),
        ("False infected", (labels == 0) & predicted),
    ]
    fig, axes = plt.subplots(4, 2, figsize=(8, 15))
    for row, (title, mask) in enumerate(cases):
        matches = np.flatnonzero(mask)
        if len(matches) == 0:
            raise ValueError(f"No test image available for: {title}")
        index = int(matches[0])
        image_bytes = tf.io.read_file(str(test.loc[index, "path"]))
        decoded = tf.io.decode_image(image_bytes, channels=3, expand_animations=False)
        image = tf.image.resize(decoded, (IMAGE_SIZE, IMAGE_SIZE))
        batch = image[None]
        with tf.GradientTape() as tape:
            x = model.get_layer("augmentation")(batch, training=False)
            x = keras.applications.mobilenet_v2.preprocess_input(x)
            features, base_output = intermediate(x, training=False)
            x = model.get_layer("global_average_pooling2d")(base_output)
            x = model.get_layer("dropout")(x, training=False)
            output = model.get_layer("prediction")(x)
            score = output[:, 0]
        gradients = tape.gradient(score, features)
        weights = tf.reduce_mean(gradients, axis=(1, 2))
        heatmap = tf.reduce_sum(features * weights[:, None, None, :], axis=-1)
        heatmap = tf.maximum(heatmap, 0)
        heatmap = heatmap / (tf.reduce_max(heatmap) + 1e-8)
        heatmap = tf.image.resize(heatmap[..., None], (IMAGE_SIZE, IMAGE_SIZE))[0, :, :, 0]

        axes[row, 0].imshow(np.uint8(np.clip(image.numpy(), 0, 255)))
        axes[row, 0].set_title(f"{title} | infected score {scores[index]:.3f}")
        axes[row, 1].imshow(np.uint8(np.clip(image.numpy(), 0, 255)))
        axes[row, 1].imshow(heatmap, cmap="jet", alpha=0.4, vmin=0, vmax=1)
        axes[row, 1].set_title("Grad-CAM for infected-class score")
        for axis in axes[row]:
            axis.axis("off")

    fig.tight_layout()
    destination = ROOT / "results" / "gradcam_cases.png"
    fig.savefig(destination, dpi=160, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {destination}")


if __name__ == "__main__":
    main()
