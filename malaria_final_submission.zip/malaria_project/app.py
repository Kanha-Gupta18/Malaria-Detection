
import json
from pathlib import Path

import numpy as np
import streamlit as st
import tensorflow as tf
from tensorflow import keras
from PIL import Image

st.set_page_config(page_title="Malaria RBC Image Classifier", page_icon="🔬", layout="wide")
st.title("🔬 Malaria RBC Image Classification")
st.caption("Educational demonstration using a CNN / MobileNetV2 model. Not a medical diagnostic tool.")

ARTIFACT_DIR = Path(__file__).resolve().parent / "models"
MODEL_PATH = ARTIFACT_DIR / "best_model.keras"
METADATA_PATH = ARTIFACT_DIR / "model_metadata.json"

@st.cache_resource
def load_artifacts():
    model = keras.models.load_model(MODEL_PATH)
    with open(METADATA_PATH, "r") as f:
        metadata = json.load(f)
    return model, metadata

if not MODEL_PATH.exists() or not METADATA_PATH.exists():
    st.error("Model files not found in the models folder.")
    st.stop()

model, metadata = load_artifacts()
img_size = int(metadata["image_size"])
model_type = metadata["model_type"]
threshold = float(metadata.get("threshold", 0.5))

uploaded = st.file_uploader("Upload one RGB red blood cell image", type=["png", "jpg", "jpeg"])

def gradcam_heatmap(image_batch):
    image_batch = tf.cast(image_batch, tf.float32)

    if model_type == "custom_cnn":
        grad_model = keras.Model(
            model.inputs,
            [model.get_layer("last_conv").output, model.output]
        )
        with tf.GradientTape() as tape:
            conv_outputs, predictions = grad_model(image_batch, training=False)
            loss = predictions[:, 0]
        grads = tape.gradient(loss, conv_outputs)
    else:
        base = model.get_layer("mobilenetv2")
        intermediate = keras.Model(
            base.input,
            [base.get_layer("out_relu").output, base.output]
        )
        with tf.GradientTape() as tape:
            x = model.get_layer("augmentation")(image_batch, training=False)
            x = keras.applications.mobilenet_v2.preprocess_input(x)
            conv_outputs, base_outputs = intermediate(x, training=False)
            x = model.get_layer("global_average_pooling2d")(base_outputs)
            x = model.get_layer("dropout")(x, training=False)
            predictions = model.get_layer("prediction")(x)
            loss = predictions[:, 0]
        grads = tape.gradient(loss, conv_outputs)

    weights = tf.reduce_mean(grads, axis=(1, 2))
    heatmap = tf.reduce_sum(conv_outputs * weights[:, None, None, :], axis=-1)
    heatmap = tf.maximum(heatmap, 0)
    heatmap = heatmap / (tf.reduce_max(heatmap, axis=(1, 2), keepdims=True) + 1e-8)
    return heatmap[0].numpy(), float(predictions[0, 0].numpy())

if uploaded:
    try:
        original = Image.open(uploaded).convert("RGB")
        original.load()
    except Exception:
        st.error("This file could not be opened as an image. Please upload a PNG or JPEG image.")
        st.stop()
    arr = tf.image.resize(np.asarray(original), (img_size, img_size)).numpy()
    resized = Image.fromarray(np.uint8(np.clip(arr, 0, 255)))
    batch = np.expand_dims(arr, axis=0)

    score = float(model.predict(batch, verbose=0)[0][0])
    label = "Parasitized" if score >= threshold else "Uninfected"

    left, right = st.columns(2)
    with left:
        st.subheader("Uploaded image")
        st.image(original, width="stretch")
    with right:
        st.subheader("Model result")
        st.metric("Predicted class", label)
        st.metric("Model output for Parasitized class", f"{score:.1%}")
        st.caption("This is a model score, not a clinically calibrated probability.")

    with st.spinner("Generating Grad-CAM visualization..."):
        try:
            heatmap, _ = gradcam_heatmap(batch)
            heat_img = Image.fromarray(np.uint8(heatmap * 255)).resize((img_size, img_size))
            heat_arr = np.asarray(heat_img)

            import matplotlib.pyplot as plt
            fig, axes = plt.subplots(1, 3, figsize=(12, 4))
            axes[0].imshow(resized)
            axes[0].set_title("Original")
            axes[1].imshow(heat_arr, cmap="jet")
            axes[1].set_title("Grad-CAM: infected-class score")
            axes[2].imshow(resized)
            axes[2].imshow(heat_arr, cmap="jet", alpha=0.4)
            axes[2].set_title("Infected-class score overlay")
            for ax in axes:
                ax.axis("off")
            st.pyplot(fig)
            plt.close(fig)
            st.caption("The heatmap shows regions influencing the infected-class score. It does not confirm parasite location.")
        except Exception as e:
            st.warning(f"Grad-CAM could not be generated for this model/runtime: {e}")

st.divider()
st.info("This educational prototype classifies individual cell images only. It is not clinically validated and must not be used for diagnosis or treatment decisions.")
