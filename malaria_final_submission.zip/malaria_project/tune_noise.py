"""Fine-tune the patient-separated MobileNetV2 with training-only image noise."""

import json

import tensorflow as tf
from tensorflow import keras

from evaluate_robustness import predict
from train_patient_split import ROOT, SEED, image_index, make_dataset, split_by_patient


def mixed_noise(images, labels):
    use_noise = tf.random.uniform((tf.shape(images)[0], 1, 1, 1)) < 0.5
    disturbed = tf.clip_by_value(images + tf.random.normal(tf.shape(images), stddev=10), 0, 255)
    return tf.where(use_noise, disturbed, images), labels


def validation_scores(model, frame):
    labels = frame.label.to_numpy()
    scores = {}
    for condition in ("clean", "gaussian_noise_sd_10"):
        probabilities = predict(model, frame.path.tolist(), condition)
        labels_predicted = (probabilities >= 0.5).astype(int)
        from sklearn.metrics import f1_score, recall_score
        scores[condition] = {
            "infected_f1": f1_score(labels, labels_predicted),
            "infected_recall": recall_score(labels, labels_predicted),
        }
    return scores


def main():
    tf.keras.utils.set_random_seed(SEED)
    train, val, _ = split_by_patient(image_index())
    counts = train.label.value_counts().to_dict()
    weights = {label: len(train) / (2 * count) for label, count in counts.items()}
    original = keras.models.load_model(ROOT / "models" / "patient_mobilenet_finetuned.keras")
    original_validation = validation_scores(original, val)
    training = make_dataset(train, training=True).map(mixed_noise, num_parallel_calls=tf.data.AUTOTUNE)
    tuned = keras.models.load_model(ROOT / "models" / "patient_mobilenet_finetuned.keras")
    tuned.compile(optimizer=keras.optimizers.Adam(5e-6), loss="binary_crossentropy", metrics=["accuracy"])
    output = ROOT / "models" / "patient_mobilenet_noise_tuned.keras"
    tuned.fit(
        training, validation_data=make_dataset(val), epochs=3, class_weight=weights,
        callbacks=[
            keras.callbacks.ModelCheckpoint(output, monitor="val_loss", save_best_only=True),
            keras.callbacks.CSVLogger(ROOT / "results" / "noise_tuning_training.csv"),
        ], verbose=2,
    )
    tuned = keras.models.load_model(output)
    tuned_validation = validation_scores(tuned, val)
    def combined(result):
        return (result["clean"]["infected_f1"] + result["gaussian_noise_sd_10"]["infected_f1"]) / 2
    selected = "noise_tuned" if combined(tuned_validation) > combined(original_validation) else "original"
    result = {
        "original_validation": original_validation,
        "noise_tuned_validation": tuned_validation,
        "selection_criterion": "mean infected F1 on clean and Gaussian-noise validation images",
        "selected": selected,
    }
    (ROOT / "results" / "noise_tuning_validation.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
