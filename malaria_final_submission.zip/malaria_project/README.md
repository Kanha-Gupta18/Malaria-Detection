# Malaria red blood cell image classifier

An educational prototype for the fourth UCS321 EST problem statement. It classifies an image of one red blood cell as **Uninfected** or **Parasitized** and displays a Grad-CAM explanation of the infected-class score. It is not a clinical diagnostic tool.

## Main result

The app uses a MobileNetV2 model trained on 140 patients, selected using 30 validation patients, and tested on **31 different patients**. On 4,408 test cell images it reached **91.79% accuracy, 86.10% infected-cell recall, 91.56% infected-cell F1, and 0.9716 ROC-AUC**. It missed 317 of 2,280 infected test cells. See [the full report](REPORT.md), [test metrics](results/patient_mobilenet_metrics.json), and [figures](results/patient_test_figures.png).

The teammate's original custom CNN and MobileNetV2 results are preserved as a comparison in the files prefixed `image_split_`. The original image-random split placed crops from the same source images and patients in both training and test sets. [The split audit](results/split_audit.json) shows the overlap; those original scores should not be interpreted as performance on unseen patients.

## Run the app

The selected model is included at `models/best_model.keras`. On Windows, use Python 3.13 and run from this folder:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Upload a PNG or JPEG image containing one red blood cell. The app shows the predicted class, the infected-class model score, and a Grad-CAM overlay. The score is not a clinically calibrated probability, and the heatmap is not a parasite annotation.

## Reproduce the analysis

The original teammate notebook is [training.ipynb](training.ipynb). It runs in Google Colab and downloads the dataset itself. Its archived outputs represent the original image-random experiment. The working copy adds class weights computed from training labels; the archived outputs have not been regenerated from that edited copy.

The patient-separated experiments were run with TensorFlow 2.21.0 on Python 3.13. `train_patient_split.py` trains the original custom CNN design; `train_patient_mobilenet.py` trains and selects the MobileNetV2 design. `tune_noise.py` records a rejected noise-fine-tuning experiment. `evaluate_robustness.py`, `generate_gradcam_cases.py`, `plot_patient_results.py`, and `audit_splits.py` reproduce the accompanying results. These scripts download the dataset through `kagglehub`; the image data is not distributed in this repository or the submission ZIP.

The dataset used here is the [NIH/NLM malaria cell image collection](https://data.lhncbc.nlm.nih.gov/public/Malaria/), accessed through its [Kaggle mirror](https://www.kaggle.com/datasets/iarunava/cell-images-for-detecting-malaria). The collection has 27,558 cell crops, with 13,779 in each class. Patient IDs were derived from filename prefixes and checked against the NIH patient mapping files. No dataset license grant is asserted here; consult the source terms before redistributing images.

## Limits

- This is cell-image classification, not a whole-slide or patient diagnosis.
- Infected-cell recall falls to 74.43% under the tested Gaussian image noise. The noise-tuned checkpoint was rejected because validation F1 fell.
- The dataset has balanced classes overall. Training-only class weights handle the modest imbalance created by the patient split; a severe imbalance scenario was not tested.
- Grad-CAM is a visual aid. It does not prove that the model found a parasite.
- The model was tested on this one dataset and has not been externally or clinically validated.

The main model's SHA-256 digest is recorded in [REPORT.md](REPORT.md). The local Python environment, dataset cache, original archives, and unused checkpoints are excluded from Git and the submission ZIP.
