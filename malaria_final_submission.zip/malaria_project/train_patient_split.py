"""Train the existing custom-CNN design with patients separated across splits."""

import json
import random
from pathlib import Path

import kagglehub
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import GroupShuffleSplit
from tensorflow import keras
from tensorflow.keras import layers


ROOT = Path(__file__).resolve().parent
SEED = 42
IMAGE_SIZE = 160
BATCH_SIZE = 32
tf.keras.utils.set_random_seed(SEED)
random.seed(SEED)
np.random.seed(SEED)


def image_index():
    base = Path(kagglehub.dataset_download("iarunava/cell-images-for-detecting-malaria"))
    folder = next(
        p.parent for p in base.rglob("Parasitized")
        if p.is_dir() and (p.parent / "Uninfected").is_dir()
    )
    rows = []
    for name, label in (("Parasitized", 1), ("Uninfected", 0)):
        for path in sorted((folder / name).glob("*.png")):
            rows.append((str(path), label, path.name.split("_IMG_")[0]))
    return pd.DataFrame(rows, columns=["path", "label", "patient"])


def split_by_patient(frame):
    train_index, held_index = next(GroupShuffleSplit(
        n_splits=1, test_size=0.3, random_state=SEED
    ).split(frame, frame.label, frame.patient))
    train = frame.iloc[train_index].reset_index(drop=True)
    held = frame.iloc[held_index].reset_index(drop=True)
    val_index, test_index = next(GroupShuffleSplit(
        n_splits=1, test_size=0.5, random_state=SEED
    ).split(held, held.label, held.patient))
    val = held.iloc[val_index].reset_index(drop=True)
    test = held.iloc[test_index].reset_index(drop=True)
    assert not (set(train.patient) & set(val.patient))
    assert not (set(train.patient) & set(test.patient))
    assert not (set(val.patient) & set(test.patient))
    return train, val, test


def make_dataset(frame, training=False):
    dataset = tf.data.Dataset.from_tensor_slices((
        frame.path.to_numpy(), frame.label.to_numpy(dtype="float32")
    ))
    if training:
        dataset = dataset.shuffle(min(len(frame), 5000), seed=SEED, reshuffle_each_iteration=True)

    def load(path, label):
        image = tf.io.decode_image(tf.io.read_file(path), channels=3, expand_animations=False)
        image.set_shape((None, None, 3))
        image = tf.image.resize(image, (IMAGE_SIZE, IMAGE_SIZE))
        return image, label

    return dataset.map(load, num_parallel_calls=tf.data.AUTOTUNE).batch(BATCH_SIZE).prefetch(tf.data.AUTOTUNE)


def build_model():
    augmentation = keras.Sequential([
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.08),
        layers.RandomZoom(0.08),
    ], name="augmentation")
    inputs = keras.Input((IMAGE_SIZE, IMAGE_SIZE, 3), name="image")
    x = augmentation(inputs)
    x = layers.Rescaling(1 / 255, name="rescale")(x)
    x = layers.Conv2D(32, 3, padding="same", activation="relu", name="conv1")(x)
    x = layers.MaxPooling2D(name="pool1")(x)
    x = layers.Conv2D(64, 3, padding="same", activation="relu", name="conv2")(x)
    x = layers.MaxPooling2D(name="pool2")(x)
    x = layers.Conv2D(128, 3, padding="same", activation="relu", name="last_conv")(x)
    x = layers.MaxPooling2D(name="pool3")(x)
    x = layers.GlobalAveragePooling2D(name="global_average_pooling2d")(x)
    x = layers.Dense(128, activation="relu", name="dense")(x)
    x = layers.Dropout(0.4, name="dropout")(x)
    outputs = layers.Dense(1, activation="sigmoid", name="prediction")(x)
    model = keras.Model(inputs, outputs, name="custom_cnn_patient_split")
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss="binary_crossentropy", metrics=["accuracy"])
    return model


def main():
    frame = image_index()
    train, val, test = split_by_patient(frame)
    counts = train.label.value_counts().to_dict()
    weights = {label: len(train) / (2 * count) for label, count in counts.items()}
    print("Split sizes:", len(train), len(val), len(test), flush=True)
    print("Training class weights:", weights, flush=True)
    model = build_model()
    destination = ROOT / "models" / "patient_split_cnn.keras"
    model.fit(
        make_dataset(train, training=True),
        validation_data=make_dataset(val),
        epochs=10,
        class_weight=weights,
        callbacks=[
            keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True),
            keras.callbacks.ReduceLROnPlateau(monitor="val_loss", patience=2, factor=0.5),
            keras.callbacks.ModelCheckpoint(destination, monitor="val_loss", save_best_only=True),
            keras.callbacks.CSVLogger(ROOT / "results" / "patient_split_training.csv"),
        ],
        verbose=2,
    )
    model = keras.models.load_model(destination)
    probability = model.predict(make_dataset(test), verbose=0).ravel()
    actual = test.label.to_numpy()
    predicted = (probability >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(actual, predicted, labels=[0, 1]).ravel()
    metrics = {
        "accuracy": accuracy_score(actual, predicted),
        "infected_precision": precision_score(actual, predicted),
        "infected_recall": recall_score(actual, predicted),
        "specificity": tn / (tn + fp),
        "infected_f1": f1_score(actual, predicted),
        "roc_auc": roc_auc_score(actual, probability),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        "train_images": len(train), "validation_images": len(val), "test_images": len(test),
        "train_patients": train.patient.nunique(),
        "validation_patients": val.patient.nunique(),
        "test_patients": test.patient.nunique(),
        "training_class_weights": weights,
        "split_seed": SEED,
    }
    output = ROOT / "results" / "patient_split_metrics.json"
    output.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2), flush=True)


if __name__ == "__main__":
    main()
