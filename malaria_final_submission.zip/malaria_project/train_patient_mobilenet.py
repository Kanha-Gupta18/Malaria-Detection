"""Test the existing MobileNetV2 design on patients unseen during training."""

import json

from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from tensorflow import keras
from tensorflow.keras import layers

from train_patient_split import ROOT, SEED, image_index, make_dataset, split_by_patient


def build_model():
    base = keras.applications.MobileNetV2(
        input_shape=(160, 160, 3), include_top=False, weights="imagenet", name="mobilenetv2"
    )
    base.trainable = False
    inputs = keras.Input((160, 160, 3), name="image")
    x = keras.Sequential([
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.08),
        layers.RandomZoom(0.08),
    ], name="augmentation")(inputs)
    x = keras.applications.mobilenet_v2.preprocess_input(x)
    x = base(x, training=False)
    x = layers.GlobalAveragePooling2D(name="global_average_pooling2d")(x)
    x = layers.Dropout(0.3, name="dropout")(x)
    outputs = layers.Dense(1, activation="sigmoid", name="prediction")(x)
    model = keras.Model(inputs, outputs, name="mobilenetv2_patient_split")
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss="binary_crossentropy", metrics=["accuracy"])
    return model, base


def metrics_for(model, dataset, labels):
    scores = model.predict(dataset, verbose=0).ravel()
    predicted = (scores >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(labels, predicted, labels=[0, 1]).ravel()
    return {
        "accuracy": accuracy_score(labels, predicted),
        "infected_precision": precision_score(labels, predicted, zero_division=0),
        "infected_recall": recall_score(labels, predicted),
        "specificity": tn / (tn + fp),
        "infected_f1": f1_score(labels, predicted),
        "roc_auc": roc_auc_score(labels, scores),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


def main():
    frame = image_index()
    train, val, test = split_by_patient(frame)
    train_data = make_dataset(train, training=True)
    val_data = make_dataset(val)
    test_data = make_dataset(test)
    counts = train.label.value_counts().to_dict()
    class_weights = {label: len(train) / (2 * count) for label, count in counts.items()}
    model, base = build_model()
    head_path = ROOT / "models" / "patient_mobilenet_head.keras"
    fine_path = ROOT / "models" / "patient_mobilenet_finetuned.keras"
    print("Training head on patient-separated data", flush=True)
    model.fit(
        train_data, validation_data=val_data, epochs=8, class_weight=class_weights,
        callbacks=[
            keras.callbacks.EarlyStopping(monitor="val_loss", patience=2, restore_best_weights=True),
            keras.callbacks.ModelCheckpoint(head_path, monitor="val_loss", save_best_only=True),
            keras.callbacks.CSVLogger(ROOT / "results" / "patient_mobilenet_head_training.csv"),
        ], verbose=2,
    )
    head = keras.models.load_model(head_path)
    head_validation = metrics_for(head, val_data, val.label.to_numpy())
    print("Head validation:", head_validation, flush=True)

    base.trainable = True
    for layer in base.layers[:-20]:
        layer.trainable = False
    for layer in base.layers:
        if isinstance(layer, layers.BatchNormalization):
            layer.trainable = False
    model.compile(optimizer=keras.optimizers.Adam(1e-5), loss="binary_crossentropy", metrics=["accuracy"])
    print("Fine-tuning final MobileNetV2 layers", flush=True)
    model.fit(
        train_data, validation_data=val_data, epochs=3, class_weight=class_weights,
        callbacks=[
            keras.callbacks.ModelCheckpoint(fine_path, monitor="val_loss", save_best_only=True),
            keras.callbacks.CSVLogger(ROOT / "results" / "patient_mobilenet_finetuning.csv"),
        ], verbose=2,
    )
    fine = keras.models.load_model(fine_path)
    fine_validation = metrics_for(fine, val_data, val.label.to_numpy())
    print("Fine-tuned validation:", fine_validation, flush=True)

    if fine_validation["infected_f1"] > head_validation["infected_f1"]:
        selected, selected_name = fine, "fine_tuned"
    else:
        selected, selected_name = head, "frozen_head"
    result = {
        "selection": selected_name,
        "head_validation": head_validation,
        "fine_tuned_validation": fine_validation,
        "selected_test": metrics_for(selected, test_data, test.label.to_numpy()),
        "train_images": len(train), "validation_images": len(val), "test_images": len(test),
        "train_patients": train.patient.nunique(),
        "validation_patients": val.patient.nunique(),
        "test_patients": test.patient.nunique(),
        "class_weights": class_weights,
        "split_seed": SEED,
    }
    (ROOT / "results" / "patient_mobilenet_metrics.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
