"""Evaluate the selected patient-separated model on controlled degradations.

Run after installing requirements: python evaluate_robustness.py
The teammate's archived results are not modified.
"""

from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageEnhance, ImageFilter
from sklearn.metrics import accuracy_score, f1_score, recall_score
import tensorflow as tf
from tensorflow import keras

from train_patient_split import image_index, split_by_patient


ROOT = Path(__file__).resolve().parent
SEED = 42
IMAGE_SIZE = 160
BATCH_SIZE = 32
THRESHOLD = 0.5


def prepare(path, condition, rng):
    image_bytes = tf.io.read_file(str(path))
    decoded = tf.io.decode_image(image_bytes, channels=3, expand_animations=False)
    pixels = tf.image.resize(decoded, (IMAGE_SIZE, IMAGE_SIZE)).numpy()
    image = Image.fromarray(np.uint8(np.clip(pixels, 0, 255)))
    if condition == "blur_radius_1":
        pixels = np.asarray(image.filter(ImageFilter.GaussianBlur(radius=1)), dtype=np.float32)
    elif condition == "brightness_80pct":
        pixels = np.asarray(ImageEnhance.Brightness(image).enhance(0.8), dtype=np.float32)
    if condition == "gaussian_noise_sd_10":
        pixels = np.clip(pixels + rng.normal(0, 10, pixels.shape), 0, 255)
    return pixels.astype(np.float32)


def predict(model, paths, condition):
    rng = np.random.default_rng(SEED)
    scores = []
    for start in range(0, len(paths), BATCH_SIZE):
        batch = np.stack([prepare(p, condition, rng) for p in paths[start:start + BATCH_SIZE]])
        scores.extend(model.predict(batch, verbose=0).ravel())
    return np.asarray(scores)


def main():
    _, _, test = split_by_patient(image_index())
    model = keras.models.load_model(ROOT / "models" / "best_model.keras")
    labels = test.label.to_numpy()
    rows = []
    for condition in ("clean", "gaussian_noise_sd_10", "blur_radius_1", "brightness_80pct"):
        scores = predict(model, test.path.tolist(), condition)
        predicted = (scores >= THRESHOLD).astype(int)
        rows.append({
            "condition": condition,
            "images": len(labels),
            "accuracy": accuracy_score(labels, predicted),
            "infected_recall": recall_score(labels, predicted),
            "f1": f1_score(labels, predicted),
            "missed_infected": int(np.sum((labels == 1) & (predicted == 0))),
        })
    output = ROOT / "results" / "robustness_comparison.csv"
    pd.DataFrame(rows).to_csv(output, index=False)
    print(pd.DataFrame(rows).to_string(index=False))
    print(f"Saved {output}")


if __name__ == "__main__":
    main()
