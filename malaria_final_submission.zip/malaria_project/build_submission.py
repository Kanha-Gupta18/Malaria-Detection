"""Create and verify the final coursework submission archive."""

import hashlib
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "malaria_final_submission.zip"
FILES = [
    "README.md",
    "REPORT.md",
    "requirements.txt",
    "training.ipynb",
    "app.py",
    "audit_splits.py",
    "evaluate_robustness.py",
    "generate_gradcam_cases.py",
    "plot_patient_results.py",
    "train_patient_split.py",
    "train_patient_mobilenet.py",
    "tune_noise.py",
    "build_submission.py",
    "models/best_model.keras",
    "models/image_split_cnn.keras",
    "models/model_metadata.json",
]


def main():
    files = [ROOT / name for name in FILES] + sorted((ROOT / "results").glob("*"))
    assert all(path.is_file() for path in files)
    manifest = []
    with ZipFile(OUTPUT, "w", ZIP_DEFLATED) as archive:
        for path in files:
            relative = path.relative_to(ROOT).as_posix()
            contents = path.read_bytes()
            archive.writestr(f"malaria_project/{relative}", contents)
            manifest.append(f"{hashlib.sha256(contents).hexdigest()}  {relative}")
        archive.writestr("malaria_project/MANIFEST.sha256", "\n".join(manifest) + "\n")
    with ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        for path in files:
            relative = path.relative_to(ROOT).as_posix()
            assert archive.read(f"malaria_project/{relative}") == path.read_bytes()
    print(f"Verified {len(files)} files in {OUTPUT} ({OUTPUT.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
