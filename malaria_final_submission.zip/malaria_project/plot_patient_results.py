"""Recreate the selected model's patient-separated test figures."""

import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay, classification_report, confusion_matrix, roc_curve, auc
from tensorflow import keras

from train_patient_split import ROOT, image_index, make_dataset, split_by_patient


def main():
    _, _, test = split_by_patient(image_index())
    model = keras.models.load_model(ROOT / "models" / "best_model.keras")
    scores = model.predict(make_dataset(test), verbose=0).ravel()
    actual = test.label.to_numpy()
    predicted = (scores >= 0.5).astype(int)

    matrix = confusion_matrix(actual, predicted, labels=[0, 1])
    false_positive_rate, true_positive_rate, _ = roc_curve(actual, scores)
    figure, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    ConfusionMatrixDisplay(matrix, display_labels=["Uninfected", "Parasitized"]).plot(
        ax=axes[0], colorbar=False, cmap="Blues", values_format="d"
    )
    axes[0].set_title("Patient-separated test: confusion matrix")
    axes[1].plot(false_positive_rate, true_positive_rate, label=f"AUC {auc(false_positive_rate, true_positive_rate):.3f}")
    axes[1].plot([0, 1], [0, 1], linestyle="--", color="gray")
    axes[1].set(xlabel="False positive rate", ylabel="True positive rate", title="Patient-separated test: ROC")
    axes[1].legend(loc="lower right")
    figure.tight_layout()
    destination = ROOT / "results" / "patient_test_figures.png"
    figure.savefig(destination, dpi=160, bbox_inches="tight")
    plt.close(figure)
    report = classification_report(
        actual, predicted, labels=[0, 1],
        target_names=["Uninfected", "Parasitized"], digits=4
    )
    (ROOT / "results" / "patient_classification_report.txt").write_text(report, encoding="utf-8")
    print(report)
    print(f"Saved {destination}")


if __name__ == "__main__":
    main()
